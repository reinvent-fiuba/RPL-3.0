#include <stdlib.h>

int segundos_a_horas_minutos_segundos(int tiempo_ingresado, int *horas, int *minutos, float *segundos);

//This text shouldnt be in the final submission package

INTEGRATION_TEST_FAILED
